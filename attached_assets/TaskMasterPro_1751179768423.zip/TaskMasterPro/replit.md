# TaskFlow - Modern Task Management Application

## Overview

TaskFlow is a modern, full-stack task management application built with React, Express, and PostgreSQL. It provides a comprehensive solution for organizing tasks, managing categories, and tracking productivity with features like Kanban boards, dashboard analytics, and user authentication through Replit Auth.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom design tokens and animations
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API with structured route handlers
- **Middleware**: Custom logging, error handling, and authentication middleware

### Database & ORM
- **Database**: PostgreSQL (using Neon serverless)
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Connection**: Connection pooling with @neondatabase/serverless

## Key Components

### Authentication System
- **Provider**: Replit Auth with OpenID Connect
- **Session Management**: Express sessions with PostgreSQL storage (connect-pg-simple)
- **User Storage**: Complete user profile management with avatar support
- **Security**: HTTP-only cookies, CSRF protection, and secure session configuration

### Task Management
- **Tasks**: Full CRUD operations with title, description, priority, status, due dates
- **Categories**: Customizable categories with colors and icons
- **Status Tracking**: Todo, In Progress, Completed workflow
- **Priority Levels**: Low, Medium, High, Urgent classification

### User Interface
- **Dashboard**: Analytics, statistics, and recent tasks overview
- **Task List**: Filterable and searchable task management
- **Kanban Board**: Drag-and-drop task organization
- **Categories**: Visual category management with usage statistics
- **Responsive Design**: Mobile-first approach with adaptive layouts

### Data Models
- **Users**: Profile information and authentication data
- **Tasks**: Core task entities with relationships to categories and users
- **Categories**: Organizational containers with customization options
- **Sessions**: Secure session storage for authentication

## Data Flow

### Client-Server Communication
1. **API Requests**: RESTful endpoints with consistent error handling
2. **Query Management**: TanStack Query for caching, synchronization, and optimistic updates
3. **Real-time Updates**: Query invalidation for immediate UI updates after mutations
4. **Error Handling**: Centralized error handling with user-friendly messaging

### Authentication Flow
1. **Login**: Redirect to Replit OAuth provider
2. **Callback**: Token validation and user profile creation/update
3. **Session**: Persistent session storage with automatic renewal
4. **Authorization**: Protected routes with middleware validation

### State Management
1. **Server State**: TanStack Query for all server-side data
2. **UI State**: React hooks for component-local state
3. **Form State**: React Hook Form with Zod validation
4. **Optimistic Updates**: Immediate UI feedback for better UX

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless connection
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/react-***: Accessible UI primitives
- **react-hook-form**: Form management with validation
- **zod**: Runtime type validation and schema definition

### Development Tools
- **Vite**: Fast build tool with HMR
- **TypeScript**: Static type checking
- **Tailwind CSS**: Utility-first styling
- **@replit/vite-plugin-***: Replit-specific development enhancements

### Authentication & Session
- **openid-client**: OIDC authentication
- **passport**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

## Deployment Strategy

### Development Environment
- **Dev Server**: Vite development server with HMR
- **API Server**: tsx for TypeScript execution with hot reload
- **Database**: Neon serverless PostgreSQL
- **Environment**: Replit cloud development environment

### Production Build
- **Frontend**: Vite build with optimization and chunking
- **Backend**: esbuild for server-side bundling
- **Static Assets**: Served through Express with proper caching headers
- **Database**: Production PostgreSQL with connection pooling

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **SESSION_SECRET**: Secure session signing key
- **REPLIT_DOMAINS**: Allowed domains for CORS
- **ISSUER_URL**: OIDC provider configuration

## Changelog

```
Changelog:
- June 29, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```