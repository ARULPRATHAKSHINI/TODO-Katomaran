import type { Express } from "express";
import { createServer, type Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import rateLimit from "express-rate-limit";
import { body, validationResult } from "express-validator";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertTaskSchema, 
  updateTaskSchema, 
  insertCategorySchema, 
  updateCategorySchema, 
  insertTaskShareSchema 
} from "@shared/schema";
import { z } from "zod";

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: "Too many requests from this IP, please try again after 15 minutes."
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // limit each IP to 5 requests per windowMs for auth endpoints
  message: "Too many authentication attempts, please try again after 15 minutes."
});

// Validation middleware
const handleValidationErrors = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Apply rate limiting
  app.use('/api/', apiLimiter);
  app.use('/api/auth/', authLimiter);

  // Replit Auth setup
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ message: "Invalid user session" });
      }
      
      const userProfile = await storage.getUser(userId);
      if (!userProfile) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(userProfile);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Category routes
  app.get('/api/categories', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const categories = await storage.getCategories(userId);
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.post('/api/categories', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const categoryData = insertCategorySchema.parse({ ...req.body, userId });
      const category = await storage.createCategory(categoryData);
      res.status(201).json(category);
    } catch (error) {
      console.error("Error creating category:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid category data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create category" });
      }
    }
  });

  app.put('/api/categories/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const categoryId = parseInt(req.params.id);
      const categoryData = updateCategorySchema.parse(req.body);
      const category = await storage.updateCategory(categoryId, categoryData, userId);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      console.error("Error updating category:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid category data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update category" });
      }
    }
  });

  app.delete('/api/categories/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const categoryId = parseInt(req.params.id);
      const success = await storage.deleteCategory(categoryId, userId);
      
      if (!success) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting category:", error);
      res.status(500).json({ message: "Failed to delete category" });
    }
  });

  // Task routes
  app.get('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const { 
        categoryId, 
        status, 
        search, 
        priority,
        dueFilter, // 'today', 'overdue', 'thisWeek'
        sortBy = 'createdAt',
        sortOrder = 'desc',
        page = '1',
        limit = '20'
      } = req.query;
      
      const filters: any = {};
      if (categoryId) filters.categoryId = parseInt(categoryId as string);
      if (status) filters.status = status;
      if (search) filters.search = search;
      if (priority) filters.priority = priority;
      if (dueFilter) filters.dueFilter = dueFilter;
      
      // Add pagination
      filters.page = parseInt(page as string);
      filters.limit = parseInt(limit as string);
      filters.sortBy = sortBy;
      filters.sortOrder = sortOrder;
      
      const tasks = await storage.getTasks(userId, filters);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.get('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const taskId = parseInt(req.params.id);
      
      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      const task = await storage.getTaskById(taskId, userId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(task);
    } catch (error) {
      console.error("Error fetching task:", error);
      res.status(500).json({ message: "Failed to fetch task" });
    }
  });

  app.post('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const taskData = insertTaskSchema.parse({ ...req.body, userId });
      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (error) {
      console.error("Error creating task:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid task data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create task" });
      }
    }
  });

  app.put('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const taskId = parseInt(req.params.id);
      const taskData = updateTaskSchema.parse(req.body);
      const task = await storage.updateTask(taskId, taskData, userId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(task);
    } catch (error) {
      console.error("Error updating task:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid task data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update task" });
      }
    }
  });

  app.delete('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const taskId = parseInt(req.params.id);
      const success = await storage.deleteTask(taskId, userId);
      
      if (!success) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  app.post('/api/tasks/:id/complete', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const taskId = parseInt(req.params.id);
      const task = await storage.completeTask(taskId, userId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(task);
    } catch (error) {
      console.error("Error completing task:", error);
      res.status(500).json({ message: "Failed to complete task" });
    }
  });

  app.get('/api/tasks/by-status', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const tasksByStatus = await storage.getTasksByStatus(userId);
      res.json(tasksByStatus);
    } catch (error) {
      console.error("Error fetching tasks by status:", error);
      res.status(500).json({ message: "Failed to fetch tasks by status" });
    }
  });

  // Dashboard routes
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const stats = await storage.getDashboardStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  app.get('/api/dashboard/recent-tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const limit = parseInt(req.query.limit as string) || 5;
      const recentTasks = await storage.getRecentTasks(userId, limit);
      res.json(recentTasks);
    } catch (error) {
      console.error("Error fetching recent tasks:", error);
      res.status(500).json({ message: "Failed to fetch recent tasks" });
    }
  });

  // Task sharing routes
  app.post('/api/tasks/:id/share', 
    isAuthenticated,
    body('email').isEmail().withMessage('Valid email is required'),
    body('permission').isIn(['view', 'edit']).withMessage('Permission must be view or edit'),
    handleValidationErrors,
    async (req: any, res) => {
      try {
        const taskId = parseInt(req.params.id);
        const userId = req.user.claims?.sub;
        const { email, permission } = req.body;

        // Check if task exists and belongs to user
        const task = await storage.getTaskById(taskId, userId);
        if (!task) {
          return res.status(404).json({ message: "Task not found" });
        }

        // Find user by email
        const targetUser = await storage.getUserByEmail(email);
        if (!targetUser) {
          return res.status(404).json({ message: "User not found" });
        }

        // Create task share
        const taskShare = await storage.shareTask({
          taskId,
          sharedWithUserId: targetUser.id,
          sharedByUserId: userId,
          permission
        });

        // Emit real-time update
        const io = req.app.get('io');
        io.to(`user:${targetUser.id}`).emit('task-shared', { task, permission });

        res.status(201).json(taskShare);
      } catch (error) {
        console.error("Error sharing task:", error);
        res.status(500).json({ message: "Failed to share task" });
      }
    }
  );

  app.get('/api/tasks/shared', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub;
      const sharedTasks = await storage.getSharedTasks(userId);
      res.json(sharedTasks);
    } catch (error) {
      console.error("Error fetching shared tasks:", error);
      res.status(500).json({ message: "Failed to fetch shared tasks" });
    }
  });

  app.delete('/api/task-shares/:id', isAuthenticated, async (req: any, res) => {
    try {
      const shareId = parseInt(req.params.id);
      const userId = req.user.claims?.sub;
      
      const success = await storage.removeTaskShare(shareId, userId);
      if (!success) {
        return res.status(404).json({ message: "Task share not found" });
      }

      res.status(204).send();
    } catch (error) {
      console.error("Error removing task share:", error);
      res.status(500).json({ message: "Failed to remove task share" });
    }
  });

  const httpServer = createServer(app);
  
  // Setup WebSocket server for real-time updates
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  // WebSocket authentication middleware
  io.use((socket, next) => {
    // For now, we'll allow connections and handle auth per event
    // In production, you'd want to verify JWT tokens here
    next();
  });

  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('join-user-room', (userId) => {
      socket.join(`user:${userId}`);
    });

    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id);
    });
  });

  // Store io instance for use in routes
  app.set('io', io);

  return httpServer;
}
