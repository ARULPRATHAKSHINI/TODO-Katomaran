import {
  users,
  categories,
  tasks,
  taskShares,
  type User,
  type UpsertUser,
  type Category,
  type InsertCategory,
  type UpdateCategory,
  type Task,
  type InsertTask,
  type UpdateTask,
  type TaskWithCategory,
  type CategoryWithCount,
  type DashboardStats,
  type InsertTaskShare,
  type TaskShare,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, count, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Category operations
  getCategories(userId: string): Promise<CategoryWithCount[]>;
  getCategoryById(id: number, userId: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: UpdateCategory, userId: string): Promise<Category | undefined>;
  deleteCategory(id: number, userId: string): Promise<boolean>;

  // Task operations
  getTasks(userId: string, filters?: { categoryId?: number; status?: string; search?: string }): Promise<TaskWithCategory[]>;
  getTaskById(id: number, userId: string): Promise<TaskWithCategory | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: UpdateTask, userId: string): Promise<Task | undefined>;
  deleteTask(id: number, userId: string): Promise<boolean>;
  completeTask(id: number, userId: string): Promise<Task | undefined>;
  getTasksByStatus(userId: string): Promise<{ [key: string]: TaskWithCategory[] }>;

  // Dashboard operations
  getDashboardStats(userId: string): Promise<DashboardStats>;
  getRecentTasks(userId: string, limit?: number): Promise<TaskWithCategory[]>;

  // Task sharing operations
  shareTask(taskShare: InsertTaskShare): Promise<TaskShare>;
  getTaskShares(taskId: number): Promise<TaskShare[]>;
  getSharedTasks(userId: string): Promise<TaskWithCategory[]>;
  removeTaskShare(id: number, userId: string): Promise<boolean>;
  getUserByEmail(email: string): Promise<User | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Category operations
  async getCategories(userId: string): Promise<CategoryWithCount[]> {
    const result = await db
      .select({
        id: categories.id,
        name: categories.name,
        color: categories.color,
        icon: categories.icon,
        userId: categories.userId,
        createdAt: categories.createdAt,
        updatedAt: categories.updatedAt,
        taskCount: count(tasks.id),
      })
      .from(categories)
      .leftJoin(tasks, and(eq(tasks.categoryId, categories.id), eq(tasks.userId, userId)))
      .where(eq(categories.userId, userId))
      .groupBy(categories.id)
      .orderBy(asc(categories.name));

    return result;
  }

  async getCategoryById(id: number, userId: string): Promise<Category | undefined> {
    const [category] = await db
      .select()
      .from(categories)
      .where(and(eq(categories.id, id), eq(categories.userId, userId)));
    return category;
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db
      .insert(categories)
      .values(category)
      .returning();
    return newCategory;
  }

  async updateCategory(id: number, category: UpdateCategory, userId: string): Promise<Category | undefined> {
    const [updatedCategory] = await db
      .update(categories)
      .set({ ...category, updatedAt: new Date() })
      .where(and(eq(categories.id, id), eq(categories.userId, userId)))
      .returning();
    return updatedCategory;
  }

  async deleteCategory(id: number, userId: string): Promise<boolean> {
    // First, update tasks to remove category reference
    await db
      .update(tasks)
      .set({ categoryId: null })
      .where(and(eq(tasks.categoryId, id), eq(tasks.userId, userId)));

    // Then delete the category
    const result = await db
      .delete(categories)
      .where(and(eq(categories.id, id), eq(categories.userId, userId)));
    return (result.rowCount ?? 0) > 0;
  }

  // Task operations
  async getTasks(userId: string, filters?: { 
    categoryId?: number; 
    status?: string; 
    search?: string;
    priority?: string;
    dueFilter?: string;
    page?: number;
    limit?: number;
    sortBy?: string;
    sortOrder?: string;
  }): Promise<TaskWithCategory[]> {
    const conditions = [eq(tasks.userId, userId)];

    if (filters?.categoryId) {
      conditions.push(eq(tasks.categoryId, filters.categoryId));
    }

    if (filters?.status) {
      conditions.push(eq(tasks.status, filters.status));
    }

    if (filters?.priority) {
      conditions.push(eq(tasks.priority, filters.priority));
    }

    if (filters?.search) {
      conditions.push(sql`LOWER(${tasks.title}) LIKE LOWER(${'%' + filters.search + '%'})`);
    }

    // Advanced date filtering
    if (filters?.dueFilter) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      switch (filters.dueFilter) {
        case 'today':
          const endOfToday = new Date(today);
          endOfToday.setHours(23, 59, 59, 999);
          conditions.push(sql`${tasks.dueDate} >= ${today.toISOString().split('T')[0]} AND ${tasks.dueDate} <= ${endOfToday.toISOString().split('T')[0]}`);
          break;
        case 'overdue':
          conditions.push(sql`${tasks.dueDate} < ${today.toISOString().split('T')[0]} AND ${tasks.status} != 'completed'`);
          break;
        case 'thisWeek':
          const endOfWeek = new Date(today);
          endOfWeek.setDate(today.getDate() + 7);
          conditions.push(sql`${tasks.dueDate} >= ${today.toISOString().split('T')[0]} AND ${tasks.dueDate} <= ${endOfWeek.toISOString().split('T')[0]}`);
          break;
      }
    }

    // Build query with sorting
    let query = db
      .select({
        id: tasks.id,
        title: tasks.title,
        description: tasks.description,
        status: tasks.status,
        priority: tasks.priority,
        dueDate: tasks.dueDate,
        completedAt: tasks.completedAt,
        position: tasks.position,
        categoryId: tasks.categoryId,
        userId: tasks.userId,
        createdAt: tasks.createdAt,
        updatedAt: tasks.updatedAt,
        category: {
          id: categories.id,
          name: categories.name,
          color: categories.color,
          icon: categories.icon,
          userId: categories.userId,
          createdAt: categories.createdAt,
          updatedAt: categories.updatedAt,
        },
      })
      .from(tasks)
      .leftJoin(categories, eq(tasks.categoryId, categories.id))
      .where(and(...conditions));

    // Apply sorting and pagination in the final query
    const sortField = filters?.sortBy || 'createdAt';
    const sortDirection = filters?.sortOrder === 'asc' ? asc : desc;
    
    let sortColumn;
    switch (sortField) {
      case 'title':
        sortColumn = sortDirection(tasks.title);
        break;
      case 'dueDate':
        sortColumn = sortDirection(tasks.dueDate);
        break;
      case 'priority':
        sortColumn = sortDirection(tasks.priority);
        break;
      case 'status':
        sortColumn = sortDirection(tasks.status);
        break;
      default:
        sortColumn = sortDirection(tasks.createdAt);
    }

    const orderedQuery = query.orderBy(sortColumn);

    // Apply pagination
    let finalQuery = orderedQuery;
    if (filters?.page && filters?.limit) {
      const offset = (filters.page - 1) * filters.limit;
      finalQuery = orderedQuery.limit(filters.limit).offset(offset);
    }

    const result = await finalQuery;

    return result.map(row => ({
      ...row,
      category: row.category?.id ? row.category : null,
    })) as TaskWithCategory[];
  }

  async getTaskById(id: number, userId: string): Promise<TaskWithCategory | undefined> {
    const [result] = await db
      .select({
        id: tasks.id,
        title: tasks.title,
        description: tasks.description,
        status: tasks.status,
        priority: tasks.priority,
        dueDate: tasks.dueDate,
        completedAt: tasks.completedAt,
        position: tasks.position,
        categoryId: tasks.categoryId,
        userId: tasks.userId,
        createdAt: tasks.createdAt,
        updatedAt: tasks.updatedAt,
        category: {
          id: categories.id,
          name: categories.name,
          color: categories.color,
          icon: categories.icon,
          userId: categories.userId,
          createdAt: categories.createdAt,
          updatedAt: categories.updatedAt,
        },
      })
      .from(tasks)
      .leftJoin(categories, eq(tasks.categoryId, categories.id))
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)));

    if (!result) return undefined;

    return {
      ...result,
      category: result.category?.id ? result.category : null,
    } as TaskWithCategory;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db
      .insert(tasks)
      .values(task)
      .returning();
    return newTask;
  }

  async updateTask(id: number, task: UpdateTask, userId: string): Promise<Task | undefined> {
    const [updatedTask] = await db
      .update(tasks)
      .set({ ...task, updatedAt: new Date() })
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
      .returning();
    return updatedTask;
  }

  async deleteTask(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(tasks)
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)));
    return (result.rowCount ?? 0) > 0;
  }

  async completeTask(id: number, userId: string): Promise<Task | undefined> {
    const [updatedTask] = await db
      .update(tasks)
      .set({ 
        status: "completed", 
        completedAt: new Date(),
        updatedAt: new Date() 
      })
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
      .returning();
    return updatedTask;
  }

  async getTasksByStatus(userId: string): Promise<{ [key: string]: TaskWithCategory[] }> {
    const allTasks = await this.getTasks(userId);
    
    return allTasks.reduce((acc, task) => {
      if (!acc[task.status]) {
        acc[task.status] = [];
      }
      acc[task.status].push(task);
      return acc;
    }, {} as { [key: string]: TaskWithCategory[] });
  }

  // Dashboard operations
  async getDashboardStats(userId: string): Promise<DashboardStats> {
    const [stats] = await db
      .select({
        total: count(),
        completed: count(sql`CASE WHEN ${tasks.status} = 'completed' THEN 1 END`),
        inProgress: count(sql`CASE WHEN ${tasks.status} = 'in-progress' THEN 1 END`),
        overdue: count(sql`CASE WHEN ${tasks.dueDate} < CURRENT_DATE AND ${tasks.status} != 'completed' THEN 1 END`),
      })
      .from(tasks)
      .where(eq(tasks.userId, userId));

    const completionRate = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;

    return {
      ...stats,
      completionRate,
    };
  }

  async getRecentTasks(userId: string, limit = 5): Promise<TaskWithCategory[]> {
    const result = await db
      .select({
        id: tasks.id,
        title: tasks.title,
        description: tasks.description,
        status: tasks.status,
        priority: tasks.priority,
        dueDate: tasks.dueDate,
        completedAt: tasks.completedAt,
        position: tasks.position,
        categoryId: tasks.categoryId,
        userId: tasks.userId,
        createdAt: tasks.createdAt,
        updatedAt: tasks.updatedAt,
        category: categories,
      })
      .from(tasks)
      .leftJoin(categories, eq(tasks.categoryId, categories.id))
      .where(eq(tasks.userId, userId))
      .orderBy(desc(tasks.updatedAt))
      .limit(limit);

    return result.map(row => ({
      ...row,
      category: row.category && row.category.id ? row.category : null,
    })) as TaskWithCategory[];
  }

  // Task sharing operations
  async shareTask(taskShare: InsertTaskShare): Promise<TaskShare> {
    const [newShare] = await db
      .insert(taskShares)
      .values(taskShare)
      .returning();
    return newShare;
  }

  async getTaskShares(taskId: number): Promise<TaskShare[]> {
    return await db
      .select()
      .from(taskShares)
      .where(eq(taskShares.taskId, taskId));
  }

  async getSharedTasks(userId: string): Promise<TaskWithCategory[]> {
    const result = await db
      .select({
        id: tasks.id,
        title: tasks.title,
        description: tasks.description,
        status: tasks.status,
        priority: tasks.priority,
        dueDate: tasks.dueDate,
        completedAt: tasks.completedAt,
        position: tasks.position,
        categoryId: tasks.categoryId,
        userId: tasks.userId,
        createdAt: tasks.createdAt,
        updatedAt: tasks.updatedAt,
        category: categories,
      })
      .from(tasks)
      .leftJoin(categories, eq(tasks.categoryId, categories.id))
      .innerJoin(taskShares, eq(tasks.id, taskShares.taskId))
      .where(eq(taskShares.sharedWithUserId, userId))
      .orderBy(desc(tasks.createdAt));

    return result.map(row => ({
      ...row,
      category: (row.category && row.category.id) ? row.category : null,
    })) as TaskWithCategory[];
  }

  async removeTaskShare(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(taskShares)
      .where(and(eq(taskShares.id, id), eq(taskShares.sharedByUserId, userId)));
    return (result.rowCount ?? 0) > 0;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }
}

export const storage = new DatabaseStorage();
