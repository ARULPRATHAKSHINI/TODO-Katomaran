import { useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { useAuth } from './useAuth';
import { useToast } from './use-toast';
import { queryClient } from '@/lib/queryClient';

export function useSocket() {
  const socket = useRef<Socket | null>(null);
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!isAuthenticated || !user) return;

    // Initialize socket connection
    socket.current = io(window.location.origin, {
      autoConnect: true,
    });

    // Join user room for targeted updates
    socket.current.emit('join-user-room', user.id);

    // Listen for real-time events
    socket.current.on('task-created', (task) => {
      // Invalidate tasks queries to refetch
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      
      toast({
        title: "Task Created",
        description: `New task "${task.title}" has been created.`,
      });
    });

    socket.current.on('task-updated', (task) => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tasks', task.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      
      toast({
        title: "Task Updated",
        description: `Task "${task.title}" has been updated.`,
      });
    });

    socket.current.on('task-deleted', (taskId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      
      toast({
        title: "Task Deleted",
        description: "A task has been deleted.",
      });
    });

    socket.current.on('task-shared', ({ task, permission }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks/shared'] });
      
      toast({
        title: "Task Shared",
        description: `Task "${task.title}" has been shared with you (${permission} access).`,
      });
    });

    socket.current.on('category-created', () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      
      toast({
        title: "Category Created",
        description: "A new category has been created.",
      });
    });

    socket.current.on('category-updated', () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      
      toast({
        title: "Category Updated",
        description: "A category has been updated.",
      });
    });

    // Cleanup on unmount
    return () => {
      if (socket.current) {
        socket.current.disconnect();
      }
    };
  }, [isAuthenticated, user, toast]);

  return socket.current;
}