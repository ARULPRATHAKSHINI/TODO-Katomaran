export interface TaskPriority {
  value: 'low' | 'medium' | 'high' | 'urgent';
  label: string;
  color: string;
  bgColor: string;
}

export interface TaskStatus {
  value: 'todo' | 'in-progress' | 'completed';
  label: string;
  color: string;
  bgColor: string;
}

export const TASK_PRIORITIES: TaskPriority[] = [
  { value: 'low', label: 'Low', color: 'text-green-600', bgColor: 'bg-green-100' },
  { value: 'medium', label: 'Medium', color: 'text-yellow-600', bgColor: 'bg-yellow-100' },
  { value: 'high', label: 'High', color: 'text-orange-600', bgColor: 'bg-orange-100' },
  { value: 'urgent', label: 'Urgent', color: 'text-red-600', bgColor: 'bg-red-100' },
];

export const TASK_STATUSES: TaskStatus[] = [
  { value: 'todo', label: 'To Do', color: 'text-gray-600', bgColor: 'bg-gray-100' },
  { value: 'in-progress', label: 'In Progress', color: 'text-blue-600', bgColor: 'bg-blue-100' },
  { value: 'completed', label: 'Completed', color: 'text-green-600', bgColor: 'bg-green-100' },
];

export const CATEGORY_COLORS = [
  '#3b82f6', // blue
  '#10b981', // emerald
  '#f59e0b', // amber
  '#ef4444', // red
  '#8b5cf6', // violet
  '#06b6d4', // cyan
  '#84cc16', // lime
  '#f97316', // orange
  '#ec4899', // pink
  '#6366f1', // indigo
];

export const CATEGORY_ICONS = [
  'folder',
  'briefcase',
  'home',
  'shopping-cart',
  'heart',
  'star',
  'target',
  'calendar',
  'book',
  'users',
  'settings',
  'globe',
];
