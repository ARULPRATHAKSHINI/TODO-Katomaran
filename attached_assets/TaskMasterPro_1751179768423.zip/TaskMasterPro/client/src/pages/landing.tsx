import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, Target, Zap, Users } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-cyan-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">TaskFlow</h1>
            </div>
            <Button 
              onClick={handleLogin}
              className="gradient-primary text-white hover:shadow-lg transition-all duration-200"
            >
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Organize Your Life with
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              {" "}TaskFlow
            </span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            A modern, intuitive task management application that helps you stay organized, 
            prioritize effectively, and achieve your goals with beautiful design and powerful features.
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="gradient-primary text-white text-lg px-8 py-4 hover:shadow-xl transition-all duration-200 transform hover:scale-105"
          >
            Get Started Free
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20 animate-slide-up">
          <Card className="card-hover border-0 shadow-lg">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Smart Organization</h3>
              <p className="text-gray-600">
                Organize tasks with categories, priorities, and due dates. 
                Never miss an important deadline again.
              </p>
            </CardContent>
          </Card>

          <Card className="card-hover border-0 shadow-lg">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Target className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Visual Progress</h3>
              <p className="text-gray-600">
                Track your progress with beautiful charts and statistics. 
                See your productivity improve over time.
              </p>
            </CardContent>
          </Card>

          <Card className="card-hover border-0 shadow-lg">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Zap className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Lightning Fast</h3>
              <p className="text-gray-600">
                Built with modern technology for blazing fast performance. 
                Your tasks load instantly, always.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Dashboard Preview */}
        <div className="text-center mb-16 animate-fade-in">
          <h3 className="text-3xl font-bold text-gray-900 mb-8">
            Beautiful, Modern Interface
          </h3>
          <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-5xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Stats Cards Preview */}
              <div className="space-y-4">
                <div className="h-24 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
                  <div className="text-white text-center">
                    <div className="text-2xl font-bold">24</div>
                    <div className="text-sm opacity-90">Total Tasks</div>
                  </div>
                </div>
                <div className="h-24 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center">
                  <div className="text-white text-center">
                    <div className="text-2xl font-bold">18</div>
                    <div className="text-sm opacity-90">Completed</div>
                  </div>
                </div>
              </div>

              {/* Task List Preview */}
              <div className="md:col-span-2">
                <div className="space-y-3">
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-xl">
                    <div className="w-4 h-4 border-2 border-blue-500 rounded-full"></div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">Complete project proposal</div>
                      <div className="text-sm text-gray-500">Work • High Priority</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-xl">
                    <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-3 h-3 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900 line-through">Review team feedback</div>
                      <div className="text-sm text-gray-500">Work • Completed</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-xl">
                    <div className="w-4 h-4 border-2 border-purple-500 rounded-full bg-purple-500"></div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">Plan weekend trip</div>
                      <div className="text-sm text-gray-500">Personal • In Progress</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-white rounded-2xl p-12 shadow-xl animate-scale-in">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">
            Ready to Get Organized?
          </h3>
          <p className="text-xl text-gray-600 mb-8">
            Join thousands of users who have transformed their productivity with TaskFlow.
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="gradient-primary text-white text-lg px-12 py-4 hover:shadow-xl transition-all duration-200 transform hover:scale-105"
          >
            Start Managing Tasks Now
          </Button>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-white/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>&copy; 2025 TaskFlow. Built with modern web technologies.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
