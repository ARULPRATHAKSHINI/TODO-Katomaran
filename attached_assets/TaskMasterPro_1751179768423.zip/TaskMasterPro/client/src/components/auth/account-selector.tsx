import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Target, Plus } from "lucide-react";

interface Account {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
}

// Mock accounts for demonstration - in real app this would come from auth provider
const mockAccounts: Account[] = [
  {
    id: "1",
    name: "Sarah Johnson",
    email: "sarah.johnson@company.com",
    avatarUrl: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100"
  },
  {
    id: "2", 
    name: "Michael Chen",
    email: "michael.chen@personal.com",
    avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100"
  }
];

interface AccountSelectorProps {
  onSelectAccount?: (account: Account) => void;
  onAddAccount?: () => void;
}

export default function AccountSelector({ onSelectAccount, onAddAccount }: AccountSelectorProps) {
  const [selectedAccountId, setSelectedAccountId] = useState<string>("");

  const handleSelectAccount = (account: Account) => {
    setSelectedAccountId(account.id);
    onSelectAccount?.(account);
  };

  const handleContinue = () => {
    // In a real app, this would initiate the auth flow with the selected account
    window.location.href = "/api/login";
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 animate-fade-in">
      <Card className="w-full max-w-md mx-4 animate-scale-in">
        <CardContent className="p-8">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Target className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Welcome to TaskFlow</h2>
            <p className="text-gray-600 mt-2">Choose your account to continue</p>
          </div>

          {/* Account Selection */}
          <div className="space-y-3 mb-6">
            {mockAccounts.map((account) => (
              <button
                key={account.id}
                onClick={() => handleSelectAccount(account)}
                className={`w-full border-2 rounded-xl p-4 hover:border-primary transition-colors text-left ${
                  selectedAccountId === account.id 
                    ? 'border-primary bg-primary/5' 
                    : 'border-gray-200'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={account.avatarUrl} alt={account.name} />
                    <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                      {getInitials(account.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 truncate">{account.name}</h3>
                    <p className="text-sm text-gray-500 truncate">{account.email}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>

          <Button 
            onClick={handleContinue}
            disabled={!selectedAccountId}
            className="w-full gradient-primary text-white font-semibold py-3 hover:shadow-lg transition-all duration-200 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
          >
            Continue with Selected Account
          </Button>

          <div className="mt-4 text-center">
            <Button 
              variant="ghost" 
              onClick={onAddAccount}
              className="text-primary hover:text-primary/80 font-medium"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Another Account
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
