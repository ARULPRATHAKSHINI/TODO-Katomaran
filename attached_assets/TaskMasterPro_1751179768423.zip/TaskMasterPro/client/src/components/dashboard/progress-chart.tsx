import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { TrendingUp } from "lucide-react";
import type { DashboardStats } from "@shared/schema";

interface ProgressChartProps {
  stats?: DashboardStats;
  isLoading: boolean;
}

export default function ProgressChart({ stats, isLoading }: ProgressChartProps) {
  if (isLoading) {
    return (
      <Card className="shadow-sm border-0">
        <CardHeader>
          <CardTitle>Weekly Progress</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="w-32 h-32 bg-gray-100 rounded-full mx-auto"></div>
            <div className="space-y-2">
              <div className="h-4 bg-gray-100 rounded w-3/4 mx-auto"></div>
              <div className="h-3 bg-gray-100 rounded w-1/2 mx-auto"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const completionRate = stats?.completionRate || 0;
  const total = stats?.total || 0;
  const completed = stats?.completed || 0;

  return (
    <Card className="shadow-sm border-0">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">Weekly Progress</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-6">
          {/* Circular Progress */}
          <div className="text-center">
            <div className="relative w-32 h-32 mx-auto">
              {/* Background Circle */}
              <div className="absolute inset-0 rounded-full border-8 border-gray-200"></div>
              
              {/* Progress Circle */}
              <div 
                className="absolute inset-0 rounded-full border-8 border-primary transition-all duration-1000 ease-out"
                style={{
                  borderTopColor: 'transparent',
                  borderRightColor: completionRate >= 25 ? 'hsl(var(--primary))' : 'transparent',
                  borderBottomColor: completionRate >= 50 ? 'hsl(var(--primary))' : 'transparent',
                  borderLeftColor: completionRate >= 75 ? 'hsl(var(--primary))' : 'transparent',
                  transform: `rotate(${(completionRate / 100) * 360 - 90}deg)`,
                }}
              />
              
              {/* Center Content */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">{completionRate}%</div>
                  <div className="text-sm text-gray-500">Complete</div>
                </div>
              </div>
            </div>
          </div>

          {/* Progress Details */}
          <div className="space-y-4">
            <div className="text-center">
              <p className="text-sm text-gray-600">
                You completed <span className="font-semibold text-gray-900">{completed} out of {total}</span> tasks this week
              </p>
              {completionRate >= 75 ? (
                <p className="text-xs text-green-600 mt-1 flex items-center justify-center">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  Excellent progress! Keep it up!
                </p>
              ) : completionRate >= 50 ? (
                <p className="text-xs text-blue-600 mt-1">Good progress! You're on track!</p>
              ) : completionRate >= 25 ? (
                <p className="text-xs text-yellow-600 mt-1">Getting started! Keep going!</p>
              ) : (
                <p className="text-xs text-gray-500 mt-1">Just getting started!</p>
              )}
            </div>

            {/* Linear Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Completion Rate</span>
                <span className="font-medium text-gray-900">{completionRate}%</span>
              </div>
              <Progress value={completionRate} className="h-2" />
            </div>

            {/* Weekly Goal */}
            <div className="p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">Weekly Goal</span>
                <span className="text-sm text-gray-600">80%</span>
              </div>
              <Progress value={Math.min(completionRate, 80)} className="h-1 mt-2" />
              {completionRate >= 80 ? (
                <p className="text-xs text-green-600 mt-1">🎉 Goal achieved!</p>
              ) : (
                <p className="text-xs text-gray-500 mt-1">
                  {80 - completionRate}% to reach your goal
                </p>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
