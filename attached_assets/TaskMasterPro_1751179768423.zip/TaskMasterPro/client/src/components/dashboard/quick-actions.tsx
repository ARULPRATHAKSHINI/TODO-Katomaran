import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import TaskForm from "@/components/task/task-form";
import CategoryForm from "@/components/category/category-form";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, FolderPlus, Download } from "lucide-react";

interface QuickActionsProps {
  showOnlyAdd?: boolean;
}

export default function QuickActions({ showOnlyAdd = false }: QuickActionsProps) {
  const [isTaskDialogOpen, setIsTaskDialogOpen] = useState(false);
  const [isCategoryDialogOpen, setIsCategoryDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const exportTasksMutation = useMutation({
    mutationFn: async () => {
      // This would be implemented as an actual export feature
      return new Promise((resolve) => {
        setTimeout(() => resolve("Export completed"), 1000);
      });
    },
    onSuccess: () => {
      toast({
        title: "Export Completed",
        description: "Your tasks have been exported successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Export Failed",
        description: "Failed to export tasks. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (showOnlyAdd) {
    return (
      <Dialog open={isTaskDialogOpen} onOpenChange={setIsTaskDialogOpen}>
        <DialogTrigger asChild>
          <Button className="gradient-primary text-white hover:shadow-lg transition-all duration-200">
            <Plus className="w-4 h-4 mr-2" />
            Add New Task
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Create New Task</DialogTitle>
          </DialogHeader>
          <TaskForm
            onSuccess={() => {
              setIsTaskDialogOpen(false);
              queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
              queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
            }}
          />
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Card className="shadow-sm border-0">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="flex flex-wrap gap-3">
          <Dialog open={isTaskDialogOpen} onOpenChange={setIsTaskDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gradient-primary text-white hover:shadow-lg transition-all duration-200 transform hover:scale-105">
                <Plus className="w-4 h-4 mr-2" />
                Add New Task
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Create New Task</DialogTitle>
              </DialogHeader>
              <TaskForm
                onSuccess={() => {
                  setIsTaskDialogOpen(false);
                  queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
                  queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
                }}
              />
            </DialogContent>
          </Dialog>

          <Dialog open={isCategoryDialogOpen} onOpenChange={setIsCategoryDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="hover:bg-gray-50 transition-colors">
                <FolderPlus className="w-4 h-4 mr-2" />
                Create Category
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Create New Category</DialogTitle>
              </DialogHeader>
              <CategoryForm
                onSuccess={() => {
                  setIsCategoryDialogOpen(false);
                  queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
                }}
              />
            </DialogContent>
          </Dialog>

          <Button 
            variant="outline" 
            className="hover:bg-gray-50 transition-colors"
            onClick={() => exportTasksMutation.mutate()}
            disabled={exportTasksMutation.isPending}
          >
            <Download className="w-4 h-4 mr-2" />
            {exportTasksMutation.isPending ? "Exporting..." : "Export Tasks"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
