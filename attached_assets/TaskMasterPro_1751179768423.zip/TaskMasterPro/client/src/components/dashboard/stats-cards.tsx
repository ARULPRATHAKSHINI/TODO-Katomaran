import { Card, CardContent } from "@/components/ui/card";
import { ListTodo, CheckCircle, Clock, AlertTriangle, TrendingUp } from "lucide-react";
import type { DashboardStats } from "@shared/schema";

interface StatsCardsProps {
  stats?: DashboardStats;
  isLoading: boolean;
}

export default function StatsCards({ stats, isLoading }: StatsCardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-24 bg-gray-100 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Total Tasks",
      value: stats?.total || 0,
      icon: ListTodo,
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      trend: "+12% from last week",
      trendIcon: TrendingUp,
      trendColor: "text-green-600",
    },
    {
      title: "Completed",
      value: stats?.completed || 0,
      icon: CheckCircle,
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      trend: `${stats?.completionRate || 0}% completion rate`,
      trendIcon: TrendingUp,
      trendColor: "text-green-600",
    },
    {
      title: "In Progress",
      value: stats?.inProgress || 0,
      icon: Clock,
      iconBg: "bg-yellow-100",
      iconColor: "text-yellow-600",
      trend: "Active tasks",
      trendIcon: null,
      trendColor: "text-yellow-600",
    },
    {
      title: "Overdue",
      value: stats?.overdue || 0,
      icon: AlertTriangle,
      iconBg: "bg-red-100",
      iconColor: "text-red-600",
      trend: "Need attention",
      trendIcon: null,
      trendColor: "text-red-600",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, index) => (
        <Card 
          key={card.title} 
          className="shadow-sm border-0 hover:shadow-md transition-shadow card-hover animate-slide-up"
          style={{ animationDelay: `${index * 0.1}s` }}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{card.title}</p>
                <p className="text-3xl font-bold text-gray-900">{card.value}</p>
              </div>
              <div className={`w-12 h-12 ${card.iconBg} rounded-xl flex items-center justify-center`}>
                <card.icon className={`w-6 h-6 ${card.iconColor}`} />
              </div>
            </div>
            <p className={`text-sm ${card.trendColor} mt-2 flex items-center`}>
              {card.trendIcon && <card.trendIcon className="w-4 h-4 mr-1" />}
              {card.trend}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
