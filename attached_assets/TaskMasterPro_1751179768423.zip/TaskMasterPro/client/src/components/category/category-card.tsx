import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { MoreVertical, Edit2, Trash2, FolderOpen } from "lucide-react";
import { cn } from "@/lib/utils";
import type { CategoryWithCount } from "@shared/schema";

interface CategoryCardProps {
  category: CategoryWithCount;
  onEdit?: (category: CategoryWithCount) => void;
  onDelete?: (categoryId: number) => void;
  showActions?: boolean;
  className?: string;
}

export default function CategoryCard({ 
  category, 
  onEdit, 
  onDelete, 
  showActions = false,
  className = ""
}: CategoryCardProps) {
  const handleEdit = () => {
    if (onEdit) {
      onEdit(category);
    }
  };

  const handleDelete = () => {
    if (onDelete) {
      onDelete(category.id);
    }
  };

  return (
    <Card className={cn(
      "shadow-sm border-0 hover:shadow-md transition-all duration-200 card-hover",
      className
    )}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 flex-1 min-w-0">
            <div 
              className="w-4 h-4 rounded-full flex-shrink-0"
              style={{ backgroundColor: category.color }}
            />
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-gray-900 truncate">{category.name}</h4>
              <div className="flex items-center space-x-2 mt-1">
                <span className="text-sm text-gray-500">
                  {category.taskCount} {category.taskCount === 1 ? 'task' : 'tasks'}
                </span>
                {category.taskCount > 0 && (
                  <Badge variant="secondary" className="text-xs">
                    Active
                  </Badge>
                )}
              </div>
            </div>
          </div>

          {showActions && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleEdit}>
                  <Edit2 className="w-4 h-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleDelete} className="text-red-600">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

        {/* Category Preview */}
        <div 
          className="mt-3 h-2 rounded-full opacity-20"
          style={{ backgroundColor: category.color }}
        />
      </CardContent>
    </Card>
  );
}
