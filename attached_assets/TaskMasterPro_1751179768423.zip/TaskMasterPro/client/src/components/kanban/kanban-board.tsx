import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import KanbanColumn from "./kanban-column";
import type { TaskWithCategory } from "@shared/schema";

interface KanbanBoardProps {
  tasksByStatus: { [key: string]: TaskWithCategory[] };
}

const COLUMN_CONFIG = [
  {
    id: 'todo',
    title: 'To Do',
    color: 'bg-gray-100',
    borderColor: 'border-gray-300',
    textColor: 'text-gray-700'
  },
  {
    id: 'in-progress',
    title: 'In Progress',
    color: 'bg-blue-100',
    borderColor: 'border-blue-300',
    textColor: 'text-blue-700'
  },
  {
    id: 'completed',
    title: 'Completed',
    color: 'bg-green-100',
    borderColor: 'border-green-300',
    textColor: 'text-green-700'
  }
];

export default function KanbanBoard({ tasksByStatus }: KanbanBoardProps) {
  const [draggedTask, setDraggedTask] = useState<TaskWithCategory | null>(null);
  const [dragOverColumn, setDragOverColumn] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateTaskMutation = useMutation({
    mutationFn: async ({ taskId, status }: { taskId: number; status: string }) => {
      await apiRequest('PUT', `/api/tasks/${taskId}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/by-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Task status updated!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update task status. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDragStart = (task: TaskWithCategory) => {
    setDraggedTask(task);
  };

  const handleDragEnd = () => {
    setDraggedTask(null);
    setDragOverColumn(null);
  };

  const handleDragOver = (columnId: string) => {
    setDragOverColumn(columnId);
  };

  const handleDrop = (columnId: string) => {
    if (draggedTask && draggedTask.status !== columnId) {
      updateTaskMutation.mutate({
        taskId: draggedTask.id,
        status: columnId
      });
    }
    setDraggedTask(null);
    setDragOverColumn(null);
  };

  return (
    <div className="h-full overflow-x-auto">
      <div className="flex space-x-6 pb-6 min-w-max">
        {COLUMN_CONFIG.map((column) => {
          const tasks = tasksByStatus[column.id] || [];
          const isDropTarget = dragOverColumn === column.id;
          
          return (
            <KanbanColumn
              key={column.id}
              id={column.id}
              title={column.title}
              tasks={tasks}
              color={column.color}
              borderColor={column.borderColor}
              textColor={column.textColor}
              isDropTarget={isDropTarget}
              onDragStart={handleDragStart}
              onDragEnd={handleDragEnd}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
            />
          );
        })}
      </div>
    </div>
  );
}
