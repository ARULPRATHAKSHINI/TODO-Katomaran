import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import TaskCard from "@/components/task/task-card";
import TaskForm from "@/components/task/task-form";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import type { TaskWithCategory } from "@shared/schema";

interface KanbanColumnProps {
  id: string;
  title: string;
  tasks: TaskWithCategory[];
  color: string;
  borderColor: string;
  textColor: string;
  isDropTarget: boolean;
  onDragStart: (task: TaskWithCategory) => void;
  onDragEnd: () => void;
  onDragOver: (columnId: string) => void;
  onDrop: (columnId: string) => void;
}

export default function KanbanColumn({
  id,
  title,
  tasks,
  color,
  borderColor,
  textColor,
  isDropTarget,
  onDragStart,
  onDragEnd,
  onDragOver,
  onDrop
}: KanbanColumnProps) {
  const [editingTask, setEditingTask] = useState<TaskWithCategory | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    onDragOver(id);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    onDrop(id);
  };

  const handleTaskDragStart = (e: React.DragEvent, task: TaskWithCategory) => {
    onDragStart(task);
  };

  const handleEdit = (task: TaskWithCategory) => {
    setEditingTask(task);
  };

  const handleEditComplete = () => {
    setEditingTask(null);
  };

  return (
    <>
      <div className="w-80 flex-shrink-0">
        <Card 
          className={cn(
            "h-full transition-all duration-200",
            isDropTarget && "drop-zone"
          )}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          <CardHeader className={cn("pb-3", color)}>
            <CardTitle className={cn(
              "flex items-center justify-between text-sm font-semibold",
              textColor
            )}>
              <span>{title}</span>
              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="text-xs">
                  {tasks.length}
                </Badge>
                {id === 'todo' && (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setIsCreateDialogOpen(true)}
                    className={cn("h-6 w-6 p-0", textColor)}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </CardTitle>
          </CardHeader>
          
          <CardContent className="p-4 space-y-3 max-h-[calc(100vh-16rem)] overflow-y-auto custom-scrollbar">
            {tasks.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3",
                  color
                )}>
                  <div className={cn("w-6 h-6 rounded-full", borderColor.replace('border-', 'bg-'))} />
                </div>
                <p className="text-sm">No tasks</p>
                {id === 'todo' && (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setIsCreateDialogOpen(true)}
                    className="mt-2 text-primary"
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    Add task
                  </Button>
                )}
              </div>
            ) : (
              tasks.map((task, index) => (
                <div
                  key={task.id}
                  draggable
                  onDragStart={(e) => handleTaskDragStart(e, task)}
                  onDragEnd={onDragEnd}
                  className={cn(
                    "animate-slide-up cursor-move",
                    "hover:shadow-md transition-shadow"
                  )}
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <TaskCard
                    task={task}
                    showCategory
                    onEdit={handleEdit}
                  />
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Create Task Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Create New Task</DialogTitle>
          </DialogHeader>
          <TaskForm
            onSuccess={() => {
              setIsCreateDialogOpen(false);
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Task Dialog */}
      <Dialog open={!!editingTask} onOpenChange={() => setEditingTask(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Task</DialogTitle>
          </DialogHeader>
          {editingTask && (
            <TaskForm
              task={editingTask}
              onSuccess={handleEditComplete}
              onCancel={handleEditComplete}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
