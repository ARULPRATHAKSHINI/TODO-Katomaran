import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Calendar, 
  MoreVertical, 
  Edit2, 
  Trash2, 
  CheckCircle,
  Clock,
  AlertTriangle
} from "lucide-react";
import { format, isAfter, isBefore, isToday } from "date-fns";
import { cn } from "@/lib/utils";
import type { TaskWithCategory } from "@shared/schema";
import { TASK_PRIORITIES, TASK_STATUSES } from "@/types";

interface TaskCardProps {
  task: TaskWithCategory;
  showCategory?: boolean;
  onEdit?: (task: TaskWithCategory) => void;
  onDelete?: (taskId: number) => void;
  onComplete?: (taskId: number) => void;
  isDragging?: boolean;
}

export default function TaskCard({ 
  task, 
  showCategory = false, 
  onEdit, 
  onDelete, 
  onComplete,
  isDragging = false 
}: TaskCardProps) {
  const [isCompleting, setIsCompleting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const priority = TASK_PRIORITIES.find(p => p.value === task.priority);
  const status = TASK_STATUSES.find(s => s.value === task.status);

  const completeTaskMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/tasks/${task.id}/complete`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/by-status"] });
      toast({
        title: "Success",
        description: "Task completed!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to complete task. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleComplete = () => {
    if (task.status === 'completed') return;
    setIsCompleting(true);
    completeTaskMutation.mutate();
  };

  const handleEdit = () => {
    if (onEdit) {
      onEdit(task);
    }
  };

  const handleDelete = () => {
    if (onDelete) {
      onDelete(task.id);
    }
  };

  const getDueDateStatus = () => {
    if (!task.dueDate) return null;
    const dueDate = new Date(task.dueDate);
    const now = new Date();
    
    if (task.status === 'completed') return null;
    
    if (isBefore(dueDate, now)) {
      return { type: 'overdue', color: 'text-red-600', bg: 'bg-red-100' };
    } else if (isToday(dueDate)) {
      return { type: 'today', color: 'text-yellow-600', bg: 'bg-yellow-100' };
    } else {
      return { type: 'upcoming', color: 'text-gray-600', bg: 'bg-gray-100' };
    }
  };

  const dueDateStatus = getDueDateStatus();
  const isCompleted = task.status === 'completed';

  return (
    <Card 
      className={cn(
        "shadow-sm border-0 hover:shadow-md transition-all duration-200 cursor-pointer",
        isDragging && "dragging",
        isCompleted && "opacity-75"
      )}
    >
      <CardContent className="p-4">
        <div className="flex items-start space-x-3">
          {/* Checkbox */}
          <div className="pt-1">
            <Checkbox
              checked={isCompleted}
              onCheckedChange={handleComplete}
              disabled={isCompleting || completeTaskMutation.isPending}
              className={cn(
                "w-5 h-5",
                isCompleted && "bg-green-500 border-green-500"
              )}
            />
          </div>

          {/* Task Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <h4 className={cn(
                  "font-medium text-gray-900 truncate",
                  isCompleted && "line-through text-gray-500"
                )}>
                  {task.title}
                </h4>
                
                {task.description && (
                  <p className={cn(
                    "text-sm text-gray-600 mt-1 line-clamp-2",
                    isCompleted && "text-gray-400"
                  )}>
                    {task.description}
                  </p>
                )}

                {/* Tags and Meta */}
                <div className="flex items-center flex-wrap gap-2 mt-3">
                  {/* Category */}
                  {showCategory && task.category && (
                    <div className="flex items-center space-x-1">
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: task.category.color }}
                      />
                      <span className="text-xs text-gray-500">{task.category.name}</span>
                    </div>
                  )}

                  {/* Priority */}
                  {priority && (
                    <Badge 
                      variant="secondary" 
                      className={cn(
                        "text-xs px-2 py-0.5",
                        `priority-${priority.value}`
                      )}
                    >
                      {priority.label}
                    </Badge>
                  )}

                  {/* Status */}
                  {status && (
                    <Badge 
                      variant="secondary" 
                      className={cn(
                        "text-xs px-2 py-0.5",
                        `status-${status.value}`
                      )}
                    >
                      {status.label}
                    </Badge>
                  )}

                  {/* Due Date */}
                  {task.dueDate && (
                    <div className={cn(
                      "flex items-center space-x-1 text-xs px-2 py-1 rounded-full",
                      dueDateStatus ? `${dueDateStatus.bg} ${dueDateStatus.color}` : "bg-gray-100 text-gray-600"
                    )}>
                      <Calendar className="w-3 h-3" />
                      <span>
                        {dueDateStatus?.type === 'overdue' && 'Overdue: '}
                        {dueDateStatus?.type === 'today' && 'Due today'}
                        {dueDateStatus?.type === 'upcoming' && 'Due: '}
                        {dueDateStatus?.type !== 'today' && format(new Date(task.dueDate), 'MMM d')}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Actions Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {!isCompleted && (
                    <DropdownMenuItem onClick={handleComplete}>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Mark Complete
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={handleEdit}>
                    <Edit2 className="w-4 h-4 mr-2" />
                    Edit
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleDelete} className="text-red-600">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
