import { useState } from "react";
import TaskCard from "./task-card";
import TaskForm from "./task-form";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import type { TaskWithCategory } from "@shared/schema";

interface TaskListProps {
  tasks: TaskWithCategory[];
  showCategory?: boolean;
  onDelete?: (taskId: number) => void;
  onComplete?: (taskId: number) => void;
  className?: string;
}

export default function TaskList({ 
  tasks, 
  showCategory = false, 
  onDelete, 
  onComplete,
  className = ""
}: TaskListProps) {
  const [editingTask, setEditingTask] = useState<TaskWithCategory | null>(null);

  const handleEdit = (task: TaskWithCategory) => {
    setEditingTask(task);
  };

  const handleEditComplete = () => {
    setEditingTask(null);
  };

  return (
    <>
      <div className={`space-y-4 ${className}`}>
        {tasks.map((task, index) => (
          <div 
            key={task.id} 
            className="animate-slide-up"
            style={{ animationDelay: `${index * 0.05}s` }}
          >
            <TaskCard
              task={task}
              showCategory={showCategory}
              onEdit={handleEdit}
              onDelete={onDelete}
              onComplete={onComplete}
            />
          </div>
        ))}
      </div>

      {/* Edit Task Dialog */}
      <Dialog open={!!editingTask} onOpenChange={() => setEditingTask(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Task</DialogTitle>
          </DialogHeader>
          {editingTask && (
            <TaskForm
              task={editingTask}
              onSuccess={handleEditComplete}
              onCancel={handleEditComplete}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
