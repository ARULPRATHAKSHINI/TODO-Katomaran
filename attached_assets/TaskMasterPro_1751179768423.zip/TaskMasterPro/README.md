# TaskFlow - Modern Task Management Application

A comprehensive, full-stack task management application built with React, Express, and PostgreSQL. TaskFlow provides an intuitive interface for organizing tasks, managing categories, and tracking productivity with features like Kanban boards, dashboard analytics, and secure authentication.

## Features

### 🎯 Task Management
- **Complete CRUD Operations**: Create, read, update, and delete tasks with ease
- **Priority Levels**: Organize tasks by Low, Medium, High, and Urgent priorities
- **Status Tracking**: Track tasks through Todo, In Progress, and Completed stages
- **Due Date Management**: Set and track task deadlines
- **Rich Descriptions**: Add detailed descriptions to tasks

### 📊 Dashboard & Analytics
- **Progress Overview**: Visual representation of task completion rates
- **Statistics Cards**: Quick overview of total, completed, in-progress, and overdue tasks
- **Recent Tasks**: Easy access to recently modified tasks
- **Performance Charts**: Track productivity trends over time

### 🗂️ Category Management
- **Custom Categories**: Create personalized categories with custom colors and icons
- **Usage Statistics**: See task counts per category
- **Visual Organization**: Color-coded categories for better task organization

### 📋 Kanban Board
- **Drag & Drop**: Intuitive drag-and-drop task management
- **Visual Workflow**: See tasks move through different stages
- **Status Columns**: Organized view of Todo, In Progress, and Completed tasks

### 🔐 Authentication & Security
- **Replit Auth Integration**: Secure authentication using Replit's OAuth system
- **Session Management**: Persistent sessions with automatic token refresh
- **Protected Routes**: Secure API endpoints with authentication middleware

### 🎨 Modern UI/UX
- **Responsive Design**: Works seamlessly on desktop and mobile devices
- **Dark/Light Mode**: Toggle between themes for comfortable viewing
- **Animated Interactions**: Smooth transitions and hover effects
- **Accessible Components**: Built with accessibility best practices

## Technology Stack

### Frontend
- **React 18** with TypeScript for type-safe development
- **Vite** for fast development and optimized builds
- **Wouter** for lightweight client-side routing
- **TanStack Query** for server state management and caching
- **Tailwind CSS** for utility-first styling
- **Radix UI** components for accessible UI primitives
- **Framer Motion** for smooth animations

### Backend
- **Node.js** with Express.js framework
- **TypeScript** for type safety across the stack
- **Passport.js** with Replit Auth for authentication
- **Express Rate Limiting** for API protection
- **Express Validator** for request validation

### Database & ORM
- **PostgreSQL** for reliable data storage
- **Drizzle ORM** for type-safe database operations
- **Drizzle Kit** for schema management
- **Connection Pooling** for optimal performance

### Development Tools
- **ESBuild** for fast TypeScript compilation
- **PostCSS** for CSS processing
- **React Hook Form** with Zod validation
- **Lucide React** for consistent iconography

## Quick Start

### Prerequisites
- Node.js 18+ 
- PostgreSQL database
- Replit account (for authentication)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd taskflow
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Setup**
   Create a `.env` file with the following variables:
   ```env
   DATABASE_URL=your_postgresql_connection_string
   SESSION_SECRET=your_session_secret_key
   REPLIT_DOMAINS=your_replit_domain
   ISSUER_URL=https://replit.com/oidc
   REPL_ID=your_repl_id
   ```

4. **Database Setup**
   ```bash
   npm run db:push
   ```

5. **Start Development Server**
   ```bash
   npm run dev
   ```

The application will be available at `http://localhost:5000`

## Project Structure

```
taskflow/
├── client/src/           # Frontend React application
│   ├── components/       # Reusable UI components
│   │   ├── auth/        # Authentication components
│   │   ├── category/    # Category management
│   │   ├── dashboard/   # Dashboard widgets
│   │   ├── kanban/      # Kanban board components
│   │   ├── layout/      # Layout components
│   │   ├── task/        # Task management
│   │   └── ui/          # Base UI components (shadcn/ui)
│   ├── hooks/           # Custom React hooks
│   ├── lib/             # Utility functions and configurations
│   ├── pages/           # Page components
│   └── types/           # TypeScript type definitions
├── server/              # Backend Express application
│   ├── db.ts           # Database connection setup
│   ├── index.ts        # Express server entry point
│   ├── routes.ts       # API route definitions
│   ├── storage.ts      # Database operations interface
│   ├── replitAuth.ts   # Replit authentication setup
│   └── vite.ts         # Vite integration for development
├── shared/              # Shared code between frontend and backend
│   └── schema.ts       # Database schema and type definitions
└── package.json        # Project dependencies and scripts
```

## Available Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build production bundle
- `npm run preview` - Preview production build
- `npm run db:push` - Push database schema changes
- `npm run db:studio` - Open Drizzle Studio for database management

## API Endpoints

### Authentication
- `GET /api/login` - Initiate Replit OAuth login
- `GET /api/logout` - Logout and clear session
- `GET /api/auth/user` - Get current user profile

### Tasks
- `GET /api/tasks` - Get user's tasks with filtering options
- `POST /api/tasks` - Create a new task
- `PUT /api/tasks/:id` - Update an existing task
- `DELETE /api/tasks/:id` - Delete a task
- `POST /api/tasks/:id/complete` - Mark task as completed
- `GET /api/tasks/by-status` - Get tasks grouped by status

### Categories
- `GET /api/categories` - Get user's categories
- `POST /api/categories` - Create a new category
- `PUT /api/categories/:id` - Update a category
- `DELETE /api/categories/:id` - Delete a category

### Dashboard
- `GET /api/dashboard/stats` - Get dashboard statistics
- `GET /api/dashboard/recent-tasks` - Get recently modified tasks

## Database Schema

### Users
- `id` - Unique identifier from Replit Auth
- `email` - User's email address
- `firstName` - User's first name
- `lastName` - User's last name
- `profileImageUrl` - Profile picture URL

### Categories
- `id` - Auto-incrementing primary key
- `name` - Category name
- `description` - Optional description
- `color` - Hex color code
- `icon` - Icon identifier
- `userId` - Reference to user

### Tasks
- `id` - Auto-incrementing primary key
- `title` - Task title
- `description` - Optional detailed description
- `status` - Current status (todo, in-progress, completed)
- `priority` - Priority level (low, medium, high, urgent)
- `dueDate` - Optional due date
- `categoryId` - Reference to category
- `userId` - Reference to user
- `createdAt` - Creation timestamp
- `updatedAt` - Last modification timestamp

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support, please open an issue in the GitHub repository or contact the development team.

---

Built with ❤️ using modern web technologies